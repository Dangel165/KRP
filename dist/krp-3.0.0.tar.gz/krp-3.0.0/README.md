# KRP (Korean Programming Language)

파이썬처럼 쉽고 한국어로 작성할 수 있는 프로그래밍 언어입니다.

## 특징

- 🇰🇷 **한국어 키워드**: 변수, 함수, 만약, 반복 등 모든 키워드가 한국어
- 🚀 **LLVM 백엔드**: 고성능 네이티브 코드 생성
- 📝 **간단한 문법**: 파이썬과 유사한 직관적인 문법
- 🔧 **ANTLR 파서**: 강력한 파서 생성기 사용
- 📚 **표준 라이브러리**: 수학, 문자열, 리스트, 랜덤 등 다양한 내장 함수
- 📦 **리스트/딕셔너리**: 배열과 해시맵 자료구조 지원
- 🎯 **클래스**: 객체 지향 프로그래밍 지원 (기본 구조)
- 📥 **모듈 시스템**: 코드 재사용을 위한 모듈 가져오기
- 🛠️ **패키지 관리자**: krp-pkg로 패키지 설치 및 관리

## 설치

### pip로 설치 (권장)

```bash
pip install krp
```

### 소스에서 설치

```bash
# 저장소 클론
git clone https://github.com/yourusername/krp.git
cd krp

# 의존성 설치
pip install -r requirements.txt

# 패키지 설치
pip install -e .
```

### LLVM 설치 (선택사항)

LLVM 컴파일 기능을 사용하려면:

```bash
# Windows
# https://releases.llvm.org/ 에서 다운로드

# Linux
sudo apt-get install llvm-14 llvm-14-dev

# macOS
brew install llvm

# Python LLVM 바인딩
pip install llvmlite
```

## 사용법

### GUI IDE (추천)

```bash
# 설치 후
krp-ide

# 또는 소스에서
python ide.py
```

Python IDLE 스타일의 통합 개발 환경:
- 문법 하이라이팅
- 코드 에디터
- 즉시 실행 (F5)
- 컴파일 (F6)
- 예제 코드 포함

### 파일 컴파일 (CLI)

```bash
# 기본 컴파일
krp examples/hello.한글

# 출력 파일 지정
krp examples/hello.한글 -o hello.o

# LLVM IR 확인
krp examples/hello.한글 --show-ir

# 실행 파일 생성
gcc hello.o -o hello
./hello
```

### 대화형 모드 (REPL)

```bash
krp --repl
```

## 문법 예제

### 변수 선언

```korean
변수 이름 = "홍길동"
변수 나이 = 25
변수 키 = 175.5
```

### 출력

```korean
보여줘("안녕하세요!")
보여줘(나이)
```

### 조건문

```korean
만약 (나이 >= 18):
    보여줘("성인입니다")
아니면:
    보여줘("미성년자입니다")
```

### 반복문

```korean
변수 i = 0
반복 (i < 10):
    보여줘(i)
    i = i + 1
```

### 함수

```korean
함수 더하기(a, b):
    변수 결과 = a + b
    반환 결과

변수 합계 = 더하기(10, 20)
보여줘(합계)
```

### 재귀 함수

```korean
함수 팩토리얼(n):
    만약 (n <= 1):
        반환 1
    아니면:
        반환 n * 팩토리얼(n - 1)

보여줘(팩토리얼(5))
```

### 리스트

```korean
# 리스트 생성
변수 숫자 = [1, 2, 3, 4, 5]
보여줘(숫자[0])  # 첫 번째 요소

# 리스트 조작
추가(숫자, 6)
보여줘(길이(숫자))
보여줘(정렬([5, 2, 8, 1]))
```

### 딕셔너리

```korean
# 딕셔너리 생성
변수 학생 = {"이름": "홍길동", "나이": 20}
보여줘(학생["이름"])

# 값 수정
학생["나이"] = 21
```

### 표준 라이브러리

```korean
# 수학 함수
보여줘(제곱근(16))        # 4.0
보여줘(절댓값(-5))        # 5
보여줘(거듭제곱(2, 10))   # 1024
보여줘(최댓값(3, 7, 2))   # 7

# 문자열 함수
보여줘(길이("안녕"))      # 2
보여줘(대문자("hello"))   # HELLO

# 랜덤 함수
보여줘(정수난수(1, 100))  # 1~100 사이 난수
보여줘(선택([1, 2, 3]))   # 랜덤 선택
```

### 클래스 (기본)

```korean
클래스 사람:
    변수 이름 = ""
    변수 나이 = 0
    
    함수 인사():
        보여줘("안녕하세요!")
        반환 참
```

### 모듈 가져오기

```korean
# 표준 라이브러리 모듈
가져오기 수학
가져오기 랜덤
가져오기 시간
```

## 키워드

| 한국어 | 설명 |
|--------|------|
| 변수 | 변수 선언 |
| 함수 | 함수 정의 |
| 클래스 | 클래스 정의 |
| 만약 | if 조건문 |
| 아니면 | else |
| 반복 | while 반복문 |
| 반환 | return |
| 보여줘 | print 출력 |
| 가져오기 | import |
| 에서 | from |
| 참 | true |
| 거짓 | false |

## 연산자

### 산술 연산자
- `+` : 덧셈
- `-` : 뺄셈
- `*` : 곱셈
- `/` : 나눗셈

### 비교 연산자
- `==` : 같음
- `!=` : 다름
- `>` : 크다
- `<` : 작다
- `>=` : 크거나 같다
- `<=` : 작거나 같다

## 표준 라이브러리

### 수학 함수
- `제곱근(x)` : 제곱근 계산
- `절댓값(x)` : 절댓값
- `올림(x)` : 올림
- `내림(x)` : 내림
- `반올림(x)` : 반올림
- `최댓값(...)` : 최댓값
- `최솟값(...)` : 최솟값
- `거듭제곱(x, y)` : x의 y제곱

### 문자열 함수
- `길이(x)` : 길이 반환
- `대문자(s)` : 대문자 변환
- `소문자(s)` : 소문자 변환
- `분리(s, sep)` : 문자열 분리
- `합치기(lst, sep)` : 리스트를 문자열로 합치기

### 리스트 함수
- `추가(lst, item)` : 리스트에 요소 추가
- `제거(lst, item)` : 리스트에서 요소 제거
- `정렬(lst)` : 정렬된 새 리스트 반환
- `뒤집기(lst)` : 뒤집힌 새 리스트 반환

### 랜덤 함수
- `난수()` : 0~1 사이 난수
- `정수난수(a, b)` : a~b 사이 정수 난수
- `선택(lst)` : 리스트에서 랜덤 선택

### 입출력 함수
- `입력(prompt)` : 사용자 입력
- `정수변환(x)` : 정수로 변환
- `실수변환(x)` : 실수로 변환
- `문자변환(x)` : 문자열로 변환

### 시간 함수
- `현재시간()` : 현재 시간 (타임스탬프)
- `대기(sec)` : 지정된 초만큼 대기

## 패키지 관리자

KRP는 `krp-pkg` 패키지 관리자를 제공합니다.

### 패키지 목록 보기

```bash
krp-pkg list
```

### 패키지 설치

```bash
# 로컬 패키지 설치
krp-pkg install mypackage --source ./mypackage
```

### 패키지 제거

```bash
krp-pkg uninstall mypackage
```

### 패키지 정보

```bash
krp-pkg info mypackage
```

### 새 패키지 생성

```bash
krp-pkg create mypackage
```

이 명령은 다음 구조의 패키지 템플릿을 생성합니다:

```
mypackage/
├── package.json
├── README.md
└── src/
    └── main.한글
```

## 프로젝트 구조

```
krp/
├── compiler/           # 컴파일러 코어
│   ├── lexer.py       # 렉서 (토큰화)
│   ├── parser.py      # 파서 (AST 생성)
│   ├── interpreter.py # 인터프리터
│   └── codegen.py     # 코드 생성 (LLVM IR)
├── grammar/           # ANTLR 문법 정의
│   └── Korean.g4      # 언어 문법
├── examples/          # 예제 코드
│   ├── hello.한글
│   ├── fibonacci.한글
│   ├── loop.한글
│   └── conditional.한글
├── main.py            # CLI 실행 파일
├── ide.py             # GUI IDE
├── requirements.txt   # 의존성
└── README.md          # 문서
```

## 개발 로드맵

- [x] 기본 문법 설계
- [x] 렉서 구현
- [x] 파서 구현
- [x] 인터프리터 구현
- [x] LLVM IR 코드 생성
- [x] GUI IDE
- [x] pip 패키지 배포
- [x] 표준 라이브러리
- [x] 배열/리스트 지원
- [x] 딕셔너리 지원
- [x] 클래스/객체 지원 (기본)
- [x] 모듈 시스템 (기본)
- [x] 패키지 관리자
- [ ] 클래스 인스턴스화
- [ ] 상속 및 다형성
- [ ] 예외 처리
- [ ] 파일 I/O
- [ ] 네트워크 라이브러리
- [ ] 원격 패키지 저장소

## 기술 스택

- **구현 언어**: Python 3.8+
- **파서 생성기**: ANTLR4
- **백엔드**: LLVM (선택사항)
- **GUI**: tkinter
- **최적화**: LLVM Optimization Passes

## 버전 히스토리

### v3.0.0 (2024)
- ✨ 표준 라이브러리 추가 (수학, 문자열, 리스트, 랜덤, 시간)
- ✨ 리스트/배열 지원 (`[1, 2, 3]`)
- ✨ 딕셔너리 지원 (`{"키": "값"}`)
- ✨ 클래스 기본 구조 지원 (`클래스` 키워드)
- ✨ 모듈 시스템 기본 구현 (`가져오기` 키워드)
- ✨ 패키지 관리자 `krp-pkg` 추가
- ✨ 리스트 인덱스 접근 및 수정
- ✨ 멤버 접근 연산자 (`.`)
- 📚 예제 파일 추가 (list_example, dict_example, stdlib_example)

### v2.0.0 (2024)
- KRP로 리브랜딩
- 패키지 이름 변경: `korean-lang` → `krp`
- 명령어 변경: `korean-lang` → `krp`, `korean-ide` → `krp-ide`
- IDE 제목 업데이트

### v1.0.1 (2024)
- 파서 버그 수정 (보여줘 문 인식 개선)
- 인터프리터 반환값 전파 수정
- 반복문 무한 루프 문제 해결

### v1.0.0 (2024)
- 초기 릴리스
- 기본 문법 구현
- LLVM 컴파일러
- 인터프리터
- GUI IDE

## 라이선스

MIT License

## 기여

이슈와 풀 리퀘스트를 환영합니다!

## 참고

- [LLVM Documentation](https://llvm.org/docs/)
- [ANTLR4 Documentation](https://github.com/antlr/antlr4/blob/master/doc/index.md)
- [llvmlite Documentation](https://llvmlite.readthedocs.io/)
